# fake-roblox-hits
fake roblox hits for discord !

this is how easy it is to "beam" dont usally trust
discord webhooks , its easy to fake them ! this is just a showcase

basically u just need an id and u can beam anyone (real 100% !!!!!) 
sometimes there be an ip error cus it didnt gen a real ip so just rerun it

## discord.gg/comped 
` pip install requests robloxpy`
